import React, { ReactNode } from 'react'

import Page from 'pages-sections/material-dashboard-2-pro-react-v2.1.0/layouts/pages/account/billing'

// const dashboardRoutes = []

export default function LandingPage(): ReactNode {
  return (
    <>
      <Page />
    </>
  )
}
