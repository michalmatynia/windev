// const dictionaries = {
//   en: () => require('./dictionaries/milkbar/v2.0/en.json'),
//   nl: () => require('./dictionaries/milkbar/v2.0/nl.json'),
// }

// export const getDictionary = async (locale) => dictionaries[locale]()
